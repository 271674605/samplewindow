# shell.
#
base=/system
export CLASSPATH=$base/framework/samplewindow.jar
exec app_process $base/bin com.android.commands.samplewindow.SampleWindow "$@"
